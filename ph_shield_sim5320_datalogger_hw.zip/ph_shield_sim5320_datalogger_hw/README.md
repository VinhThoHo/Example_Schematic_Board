# ph_shield_sim5320_datalogger_hw

ph_shield_sim5320_datalogger_hw

![Hinh 1](./assets/sim5320e_kit_top.png)

![Hinh 2](./assets/sim5320e_kit_bot.png)

