# PH_main_water_sample_hw_v2

# MCU

![Image 1](./assets/mcu_water_sample_hw-top.png)

![Image 1](./assets/mcu_water_sample_hw-bot.png)